package me.ederign;

public interface GreeterInterface {

    public String opinion();
}
