package me.ederign;

public class User {

    public boolean isActive() {
        return true;
    }
}
