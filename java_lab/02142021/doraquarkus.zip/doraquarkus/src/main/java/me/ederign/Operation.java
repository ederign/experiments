package me.ederign;

public class Operation {

}
